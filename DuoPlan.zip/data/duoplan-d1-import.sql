PRAGMA foreign_keys=ON;
BEGIN;
INSERT OR REPLACE INTO pairs(id, code, name1, name2, user_a, user_b, started_at, together_pts, created_at, updated_at) VALUES(1, '740C04B5', 'Serafim', '', 1218491598, 0, '2026-10-27', 0, 1793131796, 1793131796);
INSERT OR REPLACE INTO users(tg_id, username, display_name, role, pair_id, points, streak, last_activity, best_streak, created_at, updated_at) VALUES(1218491598, 'gheofvens', 'Serafim', 'a', 1, 0, 0, NULL, 0, 1793131784, 1793131796);
COMMIT;
