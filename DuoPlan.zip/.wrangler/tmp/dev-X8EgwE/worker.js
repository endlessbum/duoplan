var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// worker.js
var DAILY_ACTIONS = [
  "\u0412\u044B\u0434\u0435\u043B\u0438\u0442\u0435 15 \u043C\u0438\u043D\u0443\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u0440\u0443\u0433 \u0434\u043B\u044F \u0434\u0440\u0443\u0433\u0430 \u2014 \u0431\u0435\u0437 \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u043E\u0432 \u0438 \u0434\u0435\u043B.",
  "\u041D\u0430\u0437\u043E\u0432\u0438\u0442\u0435 \u0434\u0440\u0443\u0433 \u0434\u0440\u0443\u0433\u0443 \u0442\u0440\u0438 \u0432\u0435\u0449\u0438, \u0437\u0430 \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0432\u044B \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u043D\u044B \u044D\u0442\u043E\u0439 \u043D\u0435\u0434\u0435\u043B\u0435.",
  "\u0417\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u0443\u0439\u0442\u0435 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0441\u043E\u0432\u043C\u0435\u0441\u0442\u043D\u043E\u0435 \u0443\u0434\u043E\u0432\u043E\u043B\u044C\u0441\u0442\u0432\u0438\u0435 \u043D\u0430 \u0431\u043B\u0438\u0436\u0430\u0439\u0448\u0438\u0435 \u0432\u044B\u0445\u043E\u0434\u043D\u044B\u0435.",
  "\u041F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C \u0432\u043E\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0435\u043C, \u043A \u043A\u043E\u0442\u043E\u0440\u043E\u043C\u0443 \u0445\u043E\u0447\u0435\u0442\u0441\u044F \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0442\u044C\u0441\u044F.",
  "\u0421\u0434\u0435\u043B\u0430\u0439\u0442\u0435 \u0434\u0440\u0443\u0433 \u0434\u0440\u0443\u0433\u0443 \u043D\u0435\u043E\u0436\u0438\u0434\u0430\u043D\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u043B\u0438\u043C\u0435\u043D\u0442 \u2014 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0439 \u0438 \u0447\u0435\u0441\u0442\u043D\u044B\u0439.",
  "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043E\u0431\u0449\u0435\u0435 \u0434\u0435\u043B\u043E \u0438 \u0441\u0434\u0435\u043B\u0430\u0439\u0442\u0435 \u043F\u0435\u0440\u0432\u044B\u0439 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0439 \u0448\u0430\u0433 \u0432\u043C\u0435\u0441\u0442\u0435.",
  "\u0423\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u043C\u0438\u043D\u0438-\u0441\u0432\u0438\u0434\u0430\u043D\u0438\u0435: \u0447\u0430\u0439, \u043F\u0440\u043E\u0433\u0443\u043B\u043A\u0430 \u0438\u043B\u0438 \u043B\u044E\u0431\u0438\u043C\u044B\u0439 \u0444\u0438\u043B\u044C\u043C."
];
var APP_VERSION = "2026.10.28";
var DEFAULT_TZ = "Europe/Moscow";
var HttpError = class extends Error {
  static {
    __name(this, "HttpError");
  }
  constructor(status, message, code = "REQUEST_ERROR") {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var json = /* @__PURE__ */ __name((data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    ...extra
  }
}), "json");
var now = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "now");
var positiveId = /* @__PURE__ */ __name((value) => Number.isSafeInteger(Number(value)) && Number(value) > 0, "positiveId");
var clean = /* @__PURE__ */ __name((value) => String(value ?? "").trim(), "clean");
var displayName = /* @__PURE__ */ __name((user) => {
  const name = clean(user.first_name) || clean(user.username) || "\u0411\u0435\u0437 \u0438\u043C\u0435\u043D\u0438";
  return Array.from(name).slice(0, 80).join("");
}, "displayName");
function textField(body, key, max, label) {
  const value = clean(body?.[key]);
  if (!value) throw new HttpError(400, `\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u043F\u043E\u043B\u0435 \xAB${label}\xBB`, "VALIDATION_ERROR");
  if (Array.from(value).length > max) throw new HttpError(400, `\xAB${label}\xBB: \u043D\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 ${max} \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432`, "VALIDATION_ERROR");
  return value;
}
__name(textField, "textField");
function validTimeZone(value) {
  if (!value || typeof value !== "string" || value.length > 64) return null;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: value }).format();
    return value;
  } catch {
    return null;
  }
}
__name(validTimeZone, "validTimeZone");
function localDay(timeZone = DEFAULT_TZ) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: validTimeZone(timeZone) || DEFAULT_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(/* @__PURE__ */ new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}
__name(localDay, "localDay");
function validDate(value) {
  const day = clean(value);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return false;
  const parsed = /* @__PURE__ */ new Date(`${day}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === day;
}
__name(validDate, "validDate");
function safeEqual(left, right) {
  const a = new TextEncoder().encode(String(left ?? ""));
  const b = new TextEncoder().encode(String(right ?? ""));
  if (!a.length || a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a[i] ^ b[i];
  return difference === 0;
}
__name(safeEqual, "safeEqual");
async function hmac(keyData, data) {
  const key = await crypto.subtle.importKey(
    "raw",
    typeof keyData === "string" ? new TextEncoder().encode(keyData) : keyData,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data));
}
__name(hmac, "hmac");
function hex(buffer) {
  return [...new Uint8Array(buffer)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
__name(hex, "hex");
async function telegramUser(initData, token) {
  if (!initData || !token) return null;
  const params = new URLSearchParams(initData);
  const received = params.get("hash");
  const authDate = Number(params.get("auth_date"));
  if (!received || !Number.isFinite(authDate)) return null;
  if (authDate > now() + 300 || now() - authDate > 86400) return null;
  params.delete("hash");
  const check = [...params.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => `${key}=${value}`).join("\n");
  const secret = await hmac("WebAppData", token);
  const expected = hex(await hmac(secret, check));
  if (!safeEqual(expected, received)) return null;
  try {
    const user = JSON.parse(params.get("user") || "null");
    return positiveId(user?.id) ? user : null;
  } catch {
    return null;
  }
}
__name(telegramUser, "telegramUser");
async function rateLimit(env, key, limit, windowSeconds = 60) {
  const bucket = Math.floor(now() / windowSeconds);
  const bucketKey = `${key}:${bucket}`;
  await env.DB.prepare(`INSERT INTO rate_limits(bucket_key,count) VALUES(?,1)
    ON CONFLICT(bucket_key) DO UPDATE SET count=count+1`).bind(bucketKey).run();
  const row = await env.DB.prepare("SELECT count FROM rate_limits WHERE bucket_key=?").bind(bucketKey).first();
  if (bucket % 10 === 0) {
    await env.DB.prepare("DELETE FROM rate_limits WHERE bucket_key<?").bind(`${key}:${bucket - 20}`).run();
  }
  if ((row?.count || 0) > limit) throw new HttpError(429, "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432. \u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u043C\u0438\u043D\u0443\u0442\u0443.", "RATE_LIMITED");
}
__name(rateLimit, "rateLimit");
async function ensureUser(env, tgUser, requestedTimeZone) {
  const timestamp = now();
  const existing = await env.DB.prepare("SELECT * FROM users WHERE tg_id=?").bind(tgUser.id).first();
  const timezone = validTimeZone(requestedTimeZone) || existing?.timezone || DEFAULT_TZ;
  await env.DB.prepare(`INSERT INTO users(tg_id,username,display_name,timezone,created_at,updated_at) VALUES(?,?,?,?,?,?)
    ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username,display_name=excluded.display_name,
      timezone=excluded.timezone,updated_at=excluded.updated_at`).bind(tgUser.id, tgUser.username || null, displayName(tgUser), timezone, timestamp, timestamp).run();
  return env.DB.prepare("SELECT * FROM users WHERE tg_id=?").bind(tgUser.id).first();
}
__name(ensureUser, "ensureUser");
async function membership(env, userId) {
  return env.DB.prepare(`SELECT p.*,pm.role,pm.tg_id FROM pair_members pm JOIN pairs p ON p.id=pm.pair_id
    WHERE pm.tg_id=? LIMIT 1`).bind(userId).first();
}
__name(membership, "membership");
async function createPair(env, user) {
  const existing = await membership(env, user.tg_id);
  if (existing) return existing;
  const timestamp = now();
  const timezone = user.timezone || DEFAULT_TZ;
  for (let attempt = 0; attempt < 3; attempt++) {
    const code = hex(crypto.getRandomValues(new Uint8Array(4))).toUpperCase();
    try {
      await env.DB.batch([
        env.DB.prepare(`INSERT INTO pairs(code,name1,user_a,started_at,timezone,created_at,updated_at)
          VALUES(?,?,?,?,?,?,?)`).bind(code, user.display_name, user.tg_id, localDay(timezone), timezone, timestamp, timestamp),
        env.DB.prepare(`INSERT INTO pair_members(tg_id,pair_id,role,joined_at)
          SELECT ?,id,'a',? FROM pairs WHERE code=?`).bind(user.tg_id, timestamp, code),
        env.DB.prepare(`UPDATE users SET pair_id=(SELECT id FROM pairs WHERE code=?),role='a',updated_at=? WHERE tg_id=?`).bind(code, timestamp, user.tg_id)
      ]);
      return membership(env, user.tg_id);
    } catch (error) {
      const raced = await membership(env, user.tg_id);
      if (raced) return raced;
      if (attempt === 2) throw error;
    }
  }
  throw new HttpError(500, "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0437\u0434\u0430\u0442\u044C \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E", "PAIR_CREATE_FAILED");
}
__name(createPair, "createPair");
async function joinPair(env, user, rawCode) {
  const code = clean(rawCode).toUpperCase().slice(0, 16);
  if (!/^[A-F0-9]{8}$/.test(code)) throw new HttpError(400, "\u041A\u043E\u0434 \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0441\u0442\u043E\u044F\u0442\u044C \u0438\u0437 8 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432", "INVALID_CODE");
  if (await membership(env, user.tg_id)) throw new HttpError(409, "\u0412\u044B \u0443\u0436\u0435 \u0441\u043E\u0441\u0442\u043E\u0438\u0442\u0435 \u0432 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u0435", "ALREADY_PAIRED");
  const pair = await env.DB.prepare("SELECT * FROM pairs WHERE code=?").bind(code).first();
  if (!pair) throw new HttpError(404, "\u041A\u043E\u0434 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D", "CODE_NOT_FOUND");
  if (pair.user_a === user.tg_id) throw new HttpError(400, "\u042D\u0442\u043E \u0432\u0430\u0448 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 \u043A\u043E\u0434", "OWN_CODE");
  if (pair.user_b) throw new HttpError(409, "\u041F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u0443\u0436\u0435 \u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u043E", "PAIR_FULL");
  const timestamp = now();
  try {
    await env.DB.batch([
      env.DB.prepare("UPDATE pairs SET user_b=?,name2=?,updated_at=? WHERE id=? AND user_b=0").bind(user.tg_id, user.display_name, timestamp, pair.id),
      env.DB.prepare("INSERT INTO pair_members(tg_id,pair_id,role,joined_at) VALUES(?,?,'b',?)").bind(user.tg_id, pair.id, timestamp),
      env.DB.prepare("UPDATE users SET pair_id=?,role='b',updated_at=? WHERE tg_id=?").bind(pair.id, timestamp, user.tg_id)
    ]);
  } catch {
    throw new HttpError(409, "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u043E\u0439\u0442\u0438: \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u0443\u0436\u0435 \u0437\u0430\u043D\u044F\u0442\u043E", "JOIN_CONFLICT");
  }
  return membership(env, user.tg_id);
}
__name(joinPair, "joinPair");
async function leavePair(env, member) {
  const partnerId = member.role === "a" ? member.user_b : member.user_a;
  const timestamp = now();
  const operations = [];
  if (!partnerId) {
    operations.push(
      env.DB.prepare("DELETE FROM pair_members WHERE pair_id=?").bind(member.id),
      env.DB.prepare("DELETE FROM pairs WHERE id=?").bind(member.id)
    );
  } else if (member.role === "a") {
    operations.push(
      env.DB.prepare("DELETE FROM pair_members WHERE tg_id=? AND pair_id=?").bind(member.tg_id, member.id),
      env.DB.prepare(`UPDATE pairs SET user_a=user_b,name1=(SELECT display_name FROM users WHERE tg_id=?),
        user_b=0,name2='',updated_at=? WHERE id=?`).bind(partnerId, timestamp, member.id),
      env.DB.prepare("UPDATE pair_members SET role='a' WHERE tg_id=? AND pair_id=?").bind(partnerId, member.id),
      env.DB.prepare("UPDATE users SET role='a',updated_at=? WHERE tg_id=?").bind(timestamp, partnerId)
    );
  } else {
    operations.push(
      env.DB.prepare("UPDATE pairs SET user_b=0,name2='',updated_at=? WHERE id=?").bind(timestamp, member.id),
      env.DB.prepare("DELETE FROM pair_members WHERE tg_id=? AND pair_id=?").bind(member.tg_id, member.id)
    );
  }
  operations.push(env.DB.prepare("UPDATE users SET pair_id=NULL,role='a',updated_at=? WHERE tg_id=?").bind(timestamp, member.tg_id));
  await env.DB.batch(operations);
}
__name(leavePair, "leavePair");
async function dailyFor(env, pairId, timeZone) {
  const day = localDay(timeZone);
  let row = await env.DB.prepare("SELECT * FROM daily_rolls WHERE pair_id=? AND day=?").bind(pairId, day).first();
  if (!row) {
    let seed = 0;
    for (const char of `${pairId}:${day}`) seed = seed * 31 + char.charCodeAt(0) >>> 0;
    const action = DAILY_ACTIONS[seed % DAILY_ACTIONS.length];
    await env.DB.prepare("INSERT OR IGNORE INTO daily_rolls(pair_id,day,daily_value) VALUES(?,?,?)").bind(pairId, day, action).run();
    row = await env.DB.prepare("SELECT * FROM daily_rolls WHERE pair_id=? AND day=?").bind(pairId, day).first();
  }
  return { day, action: row.daily_value, done: Boolean(row.done_by), doneBy: row.done_by || null };
}
__name(dailyFor, "dailyFor");
function publicUser(user) {
  return {
    display_name: user.display_name,
    points: user.points,
    streak: user.streak,
    best_streak: user.best_streak,
    timezone: user.timezone
  };
}
__name(publicUser, "publicUser");
async function state(env, userId) {
  const user = await env.DB.prepare("SELECT * FROM users WHERE tg_id=?").bind(userId).first();
  const pair = await membership(env, userId);
  if (!pair) return { user: publicUser(user), pair: null };
  const [tasks, completedTasks, dates, memories, wishes, completedWishes, daily] = await Promise.all([
    env.DB.prepare("SELECT id,title,status,created_at FROM tasks WHERE pair_id=? AND status='open' ORDER BY created_at DESC LIMIT 100").bind(pair.id).all(),
    env.DB.prepare("SELECT id,title,status,completed_at FROM tasks WHERE pair_id=? AND status='done' ORDER BY completed_at DESC LIMIT 30").bind(pair.id).all(),
    env.DB.prepare("SELECT id,title,day,recurs,created_at FROM dates WHERE pair_id=? ORDER BY day LIMIT 100").bind(pair.id).all(),
    env.DB.prepare(`SELECT m.id,m.body,m.day,m.created_at,u.display_name FROM memories m
      LEFT JOIN users u ON u.tg_id=m.author_id WHERE m.pair_id=? ORDER BY m.created_at DESC LIMIT 100`).bind(pair.id).all(),
    env.DB.prepare(`SELECT w.id,w.body,w.created_at,u.display_name FROM wishes w
      LEFT JOIN users u ON u.tg_id=w.owner_id WHERE w.pair_id=? AND w.done=0 ORDER BY w.created_at DESC LIMIT 100`).bind(pair.id).all(),
    env.DB.prepare(`SELECT w.id,w.body,w.created_at,u.display_name FROM wishes w
      LEFT JOIN users u ON u.tg_id=w.owner_id WHERE w.pair_id=? AND w.done=1 ORDER BY w.created_at DESC LIMIT 30`).bind(pair.id).all(),
    dailyFor(env, pair.id, pair.timezone)
  ]);
  return {
    user: publicUser(user),
    pair: {
      id: pair.id,
      code: pair.user_b ? null : pair.code,
      name1: pair.name1,
      name2: pair.name2,
      user_b: pair.user_b,
      role: pair.role,
      started_at: pair.started_at,
      together_pts: pair.together_pts,
      timezone: pair.timezone
    },
    tasks: tasks.results,
    completedTasks: completedTasks.results,
    dates: dates.results,
    memories: memories.results,
    wishes: wishes.results,
    completedWishes: completedWishes.results,
    daily
  };
}
__name(state, "state");
async function readJson(request) {
  try {
    const body = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("not object");
    return body;
  } catch {
    throw new HttpError(400, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0437\u0430\u043F\u0440\u043E\u0441", "INVALID_JSON");
  }
}
__name(readJson, "readJson");
async function itemRoute(env, pair, user, method, pathname, body) {
  const match = pathname.match(/^\/api\/(tasks|dates|memories|wishes)\/(\d+)(?:\/(done|reopen))?$/);
  if (!match) return false;
  const [, type, rawId, action] = match;
  const id = Number(rawId);
  if (!positiveId(id)) throw new HttpError(400, "\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440", "INVALID_ID");
  const table = { tasks: "tasks", dates: "dates", memories: "memories", wishes: "wishes" }[type];
  if (method === "DELETE") {
    const result = await env.DB.prepare(`DELETE FROM ${table} WHERE id=? AND pair_id=?`).bind(id, pair.id).run();
    if (!result.meta.changes) throw new HttpError(404, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430", "NOT_FOUND");
    return true;
  }
  if (method === "PATCH") {
    const fields = [];
    const values = [];
    if (type === "tasks") {
      fields.push("title=?");
      values.push(textField(body, "title", 180, "\u041F\u043B\u0430\u043D"));
    } else if (type === "dates") {
      fields.push("title=?");
      values.push(textField(body, "title", 120, "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435"));
      if (!validDate(body.day)) throw new HttpError(400, "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0434\u0430\u0442\u0443", "INVALID_DATE");
      fields.push("day=?", "recurs=?");
      values.push(clean(body.day), body.recurs === false ? 0 : 1);
    } else if (type === "memories") {
      fields.push("body=?");
      values.push(textField(body, "body", 2e3, "\u0412\u043E\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0435"));
    } else {
      fields.push("body=?");
      values.push(textField(body, "body", 300, "\u0416\u0435\u043B\u0430\u043D\u0438\u0435"));
    }
    const result = await env.DB.prepare(`UPDATE ${table} SET ${fields.join(",")} WHERE id=? AND pair_id=?`).bind(...values, id, pair.id).run();
    if (!result.meta.changes) throw new HttpError(404, "\u0417\u0430\u043F\u0438\u0441\u044C \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430", "NOT_FOUND");
    return true;
  }
  if (method === "POST" && action) {
    if (!["tasks", "wishes"].includes(type)) throw new HttpError(404, "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E", "NOT_FOUND");
    let result;
    if (type === "tasks") {
      result = action === "done" ? await env.DB.prepare("UPDATE tasks SET status='done',completed_by=?,completed_at=? WHERE id=? AND pair_id=? AND status='open'").bind(user.tg_id, now(), id, pair.id).run() : await env.DB.prepare("UPDATE tasks SET status='open',completed_by=NULL,completed_at=NULL WHERE id=? AND pair_id=? AND status='done'").bind(id, pair.id).run();
    } else {
      result = action === "done" ? await env.DB.prepare("UPDATE wishes SET done=1 WHERE id=? AND pair_id=? AND done=0").bind(id, pair.id).run() : await env.DB.prepare("UPDATE wishes SET done=0 WHERE id=? AND pair_id=? AND done=1").bind(id, pair.id).run();
    }
    if (!result.meta.changes) throw new HttpError(409, "\u0417\u0430\u043F\u0438\u0441\u044C \u0443\u0436\u0435 \u0432 \u044D\u0442\u043E\u043C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0438", "NO_CHANGE");
    return true;
  }
  throw new HttpError(405, "\u041C\u0435\u0442\u043E\u0434 \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F", "METHOD_NOT_ALLOWED");
}
__name(itemRoute, "itemRoute");
async function api(request, env, url) {
  if (!env.DB) throw new HttpError(503, "\u0411\u0430\u0437\u0430 \u0434\u0430\u043D\u043D\u044B\u0445 \u0435\u0449\u0451 \u043D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0430", "DB_UNAVAILABLE");
  const initData = request.headers.get("x-telegram-init-data");
  const tgUser = await telegramUser(initData, env.BOT_TOKEN);
  if (!tgUser) throw new HttpError(401, "\u0421\u0435\u0441\u0441\u0438\u044F Telegram \u0438\u0441\u0442\u0435\u043A\u043B\u0430. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u043D\u043E\u0432\u043E.", "AUTH_EXPIRED");
  const timezone = validTimeZone(request.headers.get("x-timezone"));
  const user = await ensureUser(env, tgUser, timezone);
  await rateLimit(env, `u:${tgUser.id}`, 240, 60);
  if (request.method === "GET" && url.pathname === "/api/state") return json(await state(env, user.tg_id));
  const body = ["POST", "PATCH"].includes(request.method) ? await readJson(request) : {};
  if (request.method === "POST" && url.pathname === "/api/pair/create") {
    await createPair(env, user);
    return json(await state(env, user.tg_id));
  }
  if (request.method === "POST" && url.pathname === "/api/pair/join") {
    await joinPair(env, user, body.code);
    return json(await state(env, user.tg_id));
  }
  const pair = await membership(env, user.tg_id);
  if (!pair) throw new HttpError(409, "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0437\u0434\u0430\u0439\u0442\u0435 \u0438\u043B\u0438 \u0441\u043E\u0435\u0434\u0438\u043D\u0438\u0442\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E", "NO_PAIR");
  if (request.method === "POST" && url.pathname === "/api/pair/leave") {
    await leavePair(env, pair);
    return json(await state(env, user.tg_id));
  }
  if (request.method === "POST" && url.pathname === "/api/tasks") {
    const title = textField(body, "title", 180, "\u041F\u043B\u0430\u043D");
    await env.DB.prepare("INSERT INTO tasks(pair_id,title,created_by,created_at) VALUES(?,?,?,?)").bind(pair.id, title, user.tg_id, now()).run();
    return json(await state(env, user.tg_id));
  }
  if (request.method === "POST" && url.pathname === "/api/dates") {
    const title = textField(body, "title", 120, "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435");
    if (!validDate(body.day)) throw new HttpError(400, "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0434\u0430\u0442\u0443", "INVALID_DATE");
    await env.DB.prepare("INSERT INTO dates(pair_id,title,day,recurs,created_at) VALUES(?,?,?,?,?)").bind(pair.id, title, clean(body.day), body.recurs === false ? 0 : 1, now()).run();
    return json(await state(env, user.tg_id));
  }
  if (request.method === "POST" && url.pathname === "/api/memories") {
    const text = textField(body, "body", 2e3, "\u0412\u043E\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0435");
    await env.DB.prepare("INSERT INTO memories(pair_id,author_id,body,day,created_at) VALUES(?,?,?,?,?)").bind(pair.id, user.tg_id, text, localDay(pair.timezone), now()).run();
    return json(await state(env, user.tg_id));
  }
  if (request.method === "POST" && url.pathname === "/api/wishes") {
    const text = textField(body, "body", 300, "\u0416\u0435\u043B\u0430\u043D\u0438\u0435");
    await env.DB.prepare("INSERT INTO wishes(pair_id,owner_id,body,created_at) VALUES(?,?,?,?)").bind(pair.id, user.tg_id, text, now()).run();
    return json(await state(env, user.tg_id));
  }
  if (request.method === "POST" && url.pathname === "/api/daily/done") {
    const daily = await dailyFor(env, pair.id, pair.timezone);
    if (daily.done) return json({ ...await state(env, user.tg_id), awarded: false });
    const previous = user.last_activity ? Math.round((Date.parse(localDay(pair.timezone)) - Date.parse(user.last_activity)) / 864e5) : null;
    const streak = previous === 1 ? user.streak + 1 : 1;
    const stamp = now();
    const results = await env.DB.batch([
      env.DB.prepare("UPDATE daily_rolls SET done_by=?,done_at=? WHERE pair_id=? AND day=? AND done_by IS NULL").bind(user.tg_id, stamp, pair.id, daily.day),
      env.DB.prepare(`UPDATE users SET points=points+10,streak=?,best_streak=MAX(best_streak,?),last_activity=?,updated_at=?
        WHERE tg_id=? AND EXISTS(SELECT 1 FROM daily_rolls WHERE pair_id=? AND day=? AND done_by=? AND done_at=?)`).bind(streak, streak, daily.day, stamp, user.tg_id, pair.id, daily.day, user.tg_id, stamp),
      env.DB.prepare(`UPDATE pairs SET together_pts=together_pts+10,updated_at=?
        WHERE id=? AND EXISTS(SELECT 1 FROM daily_rolls WHERE pair_id=? AND day=? AND done_by=? AND done_at=?)`).bind(stamp, pair.id, pair.id, daily.day, user.tg_id, stamp)
    ]);
    return json({ ...await state(env, user.tg_id), awarded: results[0].meta.changes > 0 });
  }
  if (await itemRoute(env, pair, user, request.method, url.pathname, body)) {
    return json(await state(env, user.tg_id));
  }
  throw new HttpError(404, "\u0420\u0430\u0437\u0434\u0435\u043B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D", "NOT_FOUND");
}
__name(api, "api");
async function telegram(env, method, payload, attempt = 0) {
  let response;
  try {
    response = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(12e3)
    });
  } catch (error) {
    if (attempt < 2) {
      await new Promise((resolve) => setTimeout(resolve, 250 * (attempt + 1)));
      return telegram(env, method, payload, attempt + 1);
    }
    throw error;
  }
  const raw = await response.text();
  let result;
  try {
    result = JSON.parse(raw);
  } catch {
    throw new Error(`Telegram \u0432\u0435\u0440\u043D\u0443\u043B \u043D\u0435 JSON (${response.status})`);
  }
  if (result.error_code === 429 && attempt < 2) {
    const wait = Math.min(3e3, Math.max(500, Number(result.parameters?.retry_after || 1) * 1e3));
    await new Promise((resolve) => setTimeout(resolve, wait));
    return telegram(env, method, payload, attempt + 1);
  }
  if (!response.ok || !result.ok) throw new Error(result.description || `Telegram API ${response.status}`);
  return result.result;
}
__name(telegram, "telegram");
function appUrl(env, requestUrl) {
  return `${(env.APP_ORIGIN || requestUrl.origin).replace(/\/$/, "")}/app`;
}
__name(appUrl, "appUrl");
async function openApp(env, chatId, requestUrl, text) {
  return telegram(env, "sendMessage", {
    chat_id: chatId,
    text,
    reply_markup: { inline_keyboard: [[{ text: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0448\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E", web_app: { url: appUrl(env, requestUrl) } }]] }
  });
}
__name(openApp, "openApp");
async function webhook(request, env, url) {
  if (!env.WEBHOOK_SECRET || !safeEqual(request.headers.get("x-telegram-bot-api-secret-token"), env.WEBHOOK_SECRET)) {
    return new Response("Forbidden", { status: 403 });
  }
  let update;
  try {
    update = await request.json();
  } catch {
    return json({ ok: true });
  }
  if (positiveId(update?.update_id)) {
    const seen = await env.DB.prepare("INSERT OR IGNORE INTO telegram_updates(update_id,received_at) VALUES(?,?)").bind(update.update_id, now()).run();
    if (!seen.meta.changes) return json({ ok: true });
  }
  const message = update.message;
  if (!message?.text || message.chat?.type !== "private" || !positiveId(message.from?.id)) return json({ ok: true });
  try {
    const user = await ensureUser(env, message.from, null);
    const text = clean(message.text);
    const code = text.startsWith("/start ") ? text.slice(7).trim() : "";
    if (code) {
      let joined = false;
      try {
        await joinPair(env, user, code);
        joined = true;
      } catch {
      }
      await openApp(env, message.chat.id, url, joined ? "\u0413\u043E\u0442\u043E\u0432\u043E \u2014 \u0442\u0435\u043F\u0435\u0440\u044C \u0443 \u0432\u0430\u0441 \u043E\u0434\u043D\u043E \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u043D\u0430 \u0434\u0432\u043E\u0438\u0445." : "\u042D\u0442\u043E \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043A\u043E\u0434 \u0443 \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430.");
    } else if (text.startsWith("/help")) {
      await telegram(env, "sendMessage", {
        chat_id: message.chat.id,
        text: "DuoPlan \u0445\u0440\u0430\u043D\u0438\u0442 \u0432\u0430\u0448\u0438 \u043E\u0431\u0449\u0438\u0435 \u043F\u043B\u0430\u043D\u044B, \u0434\u0430\u0442\u044B, \u0432\u043E\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u044F \u0438 \u0436\u0435\u043B\u0430\u043D\u0438\u044F. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 Mini App \u043A\u043D\u043E\u043F\u043A\u043E\u0439 \u043D\u0438\u0436\u0435: \u0442\u0430\u043C \u043C\u043E\u0436\u043D\u043E \u0434\u043E\u0431\u0430\u0432\u043B\u044F\u0442\u044C, \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u0438."
      });
      await openApp(env, message.chat.id, url, "\u0412\u0430\u0448\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E \u0432\u0441\u0435\u0433\u0434\u0430 \u043F\u043E\u0434 \u0440\u0443\u043A\u043E\u0439.");
    } else {
      await openApp(env, message.chat.id, url, "\u0412\u0430\u0448\u0438 \u043F\u043B\u0430\u043D\u044B, \u0432\u043E\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u044F \u0438 \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u0440\u0430\u0434\u043E\u0441\u0442\u0438 \u2014 \u0432 \u043E\u0434\u043D\u043E\u043C \u0443\u044E\u0442\u043D\u043E\u043C \u043C\u0435\u0441\u0442\u0435.");
    }
  } catch (error) {
    console.error("webhook delivery failed", error);
  }
  return json({ ok: true });
}
__name(webhook, "webhook");
async function ensureSchema(env) {
  const statements = [
    `CREATE TABLE IF NOT EXISTS pairs (id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL UNIQUE,name1 TEXT NOT NULL,name2 TEXT NOT NULL DEFAULT '',user_a INTEGER NOT NULL,user_b INTEGER NOT NULL DEFAULT 0,started_at TEXT NOT NULL,together_pts INTEGER NOT NULL DEFAULT 0,timezone TEXT NOT NULL DEFAULT 'Europe/Moscow',created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS users (tg_id INTEGER PRIMARY KEY,username TEXT,display_name TEXT NOT NULL DEFAULT '',role TEXT NOT NULL DEFAULT 'a',pair_id INTEGER REFERENCES pairs(id) ON DELETE SET NULL,points INTEGER NOT NULL DEFAULT 0,streak INTEGER NOT NULL DEFAULT 0,last_activity TEXT,best_streak INTEGER NOT NULL DEFAULT 0,timezone TEXT NOT NULL DEFAULT 'Europe/Moscow',created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS pair_members (tg_id INTEGER PRIMARY KEY,pair_id INTEGER NOT NULL REFERENCES pairs(id) ON DELETE CASCADE,role TEXT NOT NULL DEFAULT 'a',joined_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT,pair_id INTEGER NOT NULL REFERENCES pairs(id) ON DELETE CASCADE,title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_by INTEGER NOT NULL,created_at INTEGER NOT NULL,completed_by INTEGER,completed_at INTEGER)`,
    `CREATE TABLE IF NOT EXISTS dates (id INTEGER PRIMARY KEY AUTOINCREMENT,pair_id INTEGER NOT NULL REFERENCES pairs(id) ON DELETE CASCADE,title TEXT NOT NULL,day TEXT NOT NULL,recurs INTEGER NOT NULL DEFAULT 1,created_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT,pair_id INTEGER NOT NULL REFERENCES pairs(id) ON DELETE CASCADE,author_id INTEGER NOT NULL,body TEXT NOT NULL,day TEXT NOT NULL,created_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS wishes (id INTEGER PRIMARY KEY AUTOINCREMENT,pair_id INTEGER NOT NULL REFERENCES pairs(id) ON DELETE CASCADE,owner_id INTEGER NOT NULL,body TEXT NOT NULL,done INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS daily_rolls (pair_id INTEGER NOT NULL REFERENCES pairs(id) ON DELETE CASCADE,day TEXT NOT NULL,daily_value TEXT NOT NULL,done_by INTEGER,done_at INTEGER,PRIMARY KEY (pair_id,day))`,
    `CREATE TABLE IF NOT EXISTS rate_limits (bucket_key TEXT PRIMARY KEY,count INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS telegram_updates (update_id INTEGER PRIMARY KEY,received_at INTEGER NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_tasks_pair ON tasks(pair_id,status)`,
    `CREATE INDEX IF NOT EXISTS idx_dates_pair ON dates(pair_id,day)`,
    `CREATE INDEX IF NOT EXISTS idx_memories_pair ON memories(pair_id,created_at)`,
    `CREATE INDEX IF NOT EXISTS idx_wishes_pair ON wishes(pair_id,done)`,
    `CREATE INDEX IF NOT EXISTS idx_pair_members_pair ON pair_members(pair_id)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_pair_members_role ON pair_members(pair_id,role)`
  ];
  await env.DB.batch(statements.map((sql) => env.DB.prepare(sql)));
  for (const [table, column, definition] of [
    ["users", "timezone", "TEXT NOT NULL DEFAULT 'Europe/Moscow'"],
    ["pairs", "timezone", "TEXT NOT NULL DEFAULT 'Europe/Moscow'"]
  ]) {
    const info = await env.DB.prepare(`PRAGMA table_info(${table})`).all();
    if (!info.results.some((row) => row.name === column)) {
      await env.DB.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();
    }
  }
  await env.DB.batch([
    env.DB.prepare(`INSERT OR IGNORE INTO pair_members(tg_id,pair_id,role,joined_at)
      SELECT user_a,id,'a',created_at FROM pairs WHERE user_a!=0 AND EXISTS(SELECT 1 FROM users WHERE tg_id=pairs.user_a)`),
    env.DB.prepare(`INSERT OR IGNORE INTO pair_members(tg_id,pair_id,role,joined_at)
      SELECT user_b,id,'b',created_at FROM pairs WHERE user_b!=0 AND EXISTS(SELECT 1 FROM users WHERE tg_id=pairs.user_b)`)
  ]);
}
__name(ensureSchema, "ensureSchema");
async function setup(request, env, url) {
  const missing = ["BOT_TOKEN", "WEBHOOK_SECRET"].filter((key) => !env[key]);
  if (missing.length) {
    return json({ error: `Cloudflare Worker \u043D\u0435 \u0432\u0438\u0434\u0438\u0442: ${missing.join(", ")}`, missing }, 503);
  }
  const ip = request.headers.get("cf-connecting-ip") || "unknown";
  const supplied = request.headers.get("x-setup-token") || (request.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const expected = env.SETUP_TOKEN || env.BOT_TOKEN;
  if (!safeEqual(supplied, expected)) return json({ error: "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0441\u0435\u043A\u0440\u0435\u0442 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438" }, 403, { "www-authenticate": "Bearer" });
  const origin = request.headers.get("origin");
  if (origin && origin !== (env.APP_ORIGIN || url.origin)) return json({ error: "Origin \u043D\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D" }, 403);
  try {
    await ensureSchema(env);
  } catch (error) {
    console.error("D1 setup failed", error);
    return json({ error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u044B D1" }, 500);
  }
  await rateLimit(env, `setup:${ip}`, 5, 600);
  const base = (env.APP_ORIGIN || url.origin).replace(/\/$/, "");
  try {
    await telegram(env, "setWebhook", {
      url: `${base}/telegram/webhook`,
      secret_token: env.WEBHOOK_SECRET,
      allowed_updates: ["message"],
      drop_pending_updates: false
    });
    await Promise.all([
      telegram(env, "setMyCommands", { commands: [
        { command: "menu", description: "\u041D\u0430\u0448\u0435 \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E" },
        { command: "help", description: "\u041A\u0430\u043A \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 DuoPlan" }
      ] }),
      telegram(env, "setChatMenuButton", { menu_button: { type: "web_app", text: "DuoPlan", web_app: { url: `${base}/app` } } })
    ]);
    await env.DB.prepare("INSERT INTO app_meta(key,value) VALUES('setup_version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(APP_VERSION).run();
  } catch (error) {
    console.error("Telegram setup failed", error);
    return json({ error: "\u0422\u0430\u0431\u043B\u0438\u0446\u044B \u0433\u043E\u0442\u043E\u0432\u044B, \u043D\u043E Telegram \u043D\u0435 \u043E\u0442\u0432\u0435\u0442\u0438\u043B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 BOT_TOKEN." }, 502);
  }
  return json({ ok: true, webhook_url: `${base}/telegram/webhook`, mini_app_url: `${base}/app`, version: APP_VERSION });
}
__name(setup, "setup");
var worker_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/health") {
        let database = false;
        try {
          await env.DB.prepare("SELECT 1").first();
          database = true;
        } catch {
        }
        return json({
          ok: database,
          service: "duoplan",
          version: APP_VERSION,
          database,
          bot_token: Boolean(env.BOT_TOKEN),
          webhook_secret: Boolean(env.WEBHOOK_SECRET)
        }, database ? 200 : 503);
      }
      if (url.pathname === "/api/setup" && request.method === "POST") return await setup(request, env, url);
      if (url.pathname.startsWith("/api/")) return await api(request, env, url);
      if (url.pathname === "/telegram/webhook" && request.method === "POST") return await webhook(request, env, url);
      return env.ASSETS.fetch(request);
    } catch (error) {
      if (error instanceof HttpError) return json({ error: error.message, code: error.code }, error.status);
      console.error(error);
      return json({ error: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0437\u0430\u043F\u0440\u043E\u0441. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.", code: "INTERNAL_ERROR" }, 500);
    }
  }
};

// C:/Users/benq/.workbuddy-ai/binaries/node/workspace/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// C:/Users/benq/.workbuddy-ai/binaries/node/workspace/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError(e);
    const body = JSON.stringify(error);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// .wrangler/tmp/bundle-1zv6nP/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = worker_default;

// C:/Users/benq/.workbuddy-ai/binaries/node/workspace/node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// .wrangler/tmp/bundle-1zv6nP/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=worker.js.map
